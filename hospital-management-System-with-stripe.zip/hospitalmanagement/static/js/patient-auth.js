import { auth } from './firebase-config.js';

// Handle patient login
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('id_username').value;
    const password = document.getElementById('id_password').value;
    
    try {
        // Sign in with Firebase
        const userCredential = await auth.signInWithEmailAndPassword(username, password);
        const user = userCredential.user;
        
        // If Firebase authentication is successful, submit the Django form
        document.getElementById('loginForm').submit();
    } catch (error) {
        console.error('Error:', error);
        alert(error.message);
    }
});

// Handle patient signup
document.getElementById('signupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('id_username').value;
    const password = document.getElementById('id_password').value;
    const firstName = document.getElementById('id_first_name').value;
    const lastName = document.getElementById('id_last_name').value;
    
    try {
        // Create user in Firebase
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        // Update user profile
        await user.updateProfile({
            displayName: `${firstName} ${lastName}`
        });
        
        // If Firebase authentication is successful, submit the Django form
        document.getElementById('signupForm').submit();
    } catch (error) {
        console.error('Error:', error);
        alert(error.message);
    }
}); 