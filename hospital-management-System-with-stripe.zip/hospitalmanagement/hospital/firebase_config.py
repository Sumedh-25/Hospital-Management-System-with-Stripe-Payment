import firebase_admin
from firebase_admin import credentials, auth, firestore

# Initialize Firebase Admin SDK only if credentials file exists
try:
    cred = credentials.Certificate("hospital/serviceAccountKey.json")
    firebase_admin.initialize_app(cred)
    db = firestore.client()
except FileNotFoundError:
    print("Firebase credentials not found. Running without Firebase integration.")
    db = None

def create_user(email, password, display_name):
    if not db:
        return None
    try:
        user = auth.create_user(
            email=email,
            password=password,
            display_name=display_name
        )
        return user
    except Exception as e:
        print(f"Error creating user: {e}")
        return None

def verify_token(id_token):
    if not db:
        return None
    try:
        decoded_token = auth.verify_id_token(id_token)
        return decoded_token
    except Exception as e:
        print(f"Error verifying token: {e}")
        return None 